//
//  AirPrintController.m
//  Usage of Air-Print feature in IOS
//
//  Created by Madhav on 18/06/13.
//  Copyright (c) 2013 kony. All rights reserved.
//

#import "AirPrintController.h"

@interface AirPrintController ()

@end

@implementation AirPrintController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

+ (void) performScreenCaptureAndPrintUsingAirPrintFeature {
    
    //Take current snapshot of current screen and save as image
    UIGraphicsBeginImageContext([[UIScreen mainScreen] bounds].size);
    //[self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
    [[[UIApplication sharedApplication] keyWindow].layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    NSData *imageData = UIImageJPEGRepresentation(image, 1.0);
    
    //Now pass this image data to a airprint enabled printer
    
    UIPrintInteractionController *prntIntrCtrlr = [UIPrintInteractionController sharedPrintController];
    if  (prntIntrCtrlr && [UIPrintInteractionController canPrintData:imageData] ) {
        prntIntrCtrlr.delegate = self;
        
        UIPrintInfo *printInfo = [UIPrintInfo printInfo];
        printInfo.outputType = UIPrintInfoOutputGeneral;
        printInfo.jobName = @"ImagePrint";
        printInfo.duplex = UIPrintInfoDuplexLongEdge;
        prntIntrCtrlr.printInfo = printInfo;
        prntIntrCtrlr.showsPageRange = YES;
        prntIntrCtrlr.printingItem = imageData;
        
        void (^completionHandler)(UIPrintInteractionController *, BOOL, NSError *) =
        ^(UIPrintInteractionController *prntIntrCtrlr, BOOL completed, NSError *error) {
            
            if (!completed && error)
                NSLog(@"FAILED! due to error in domain %u with error code %u",error.domain, error.code);
        };
        
        [prntIntrCtrlr presentAnimated:YES completionHandler:completionHandler];        
        
        
    }
    
    
    
    
}

@end
