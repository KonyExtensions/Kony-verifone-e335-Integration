//
//  AirPrintController.h
//  Usage of Air-Print feature in IOS
//
//  Created by Madhav on 18/06/13.
//  Copyright (c) 2013 kony. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface AirPrintController : UIViewController <UIPrintInteractionControllerDelegate>
+(void) performScreenCaptureAndPrintUsingAirPrintFeature;
- (void) print;
@end
